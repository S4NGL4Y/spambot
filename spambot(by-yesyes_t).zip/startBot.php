<?php
require 'vendor/autoload.php';

use danog\MadelineProto\API;
use danog\MadelineProto\Settings;
use danog\MadelineProto\Settings\AppInfo;
use danog\MadelineProto\Settings\Logger;

$settings = new Settings([
    'app_info' => new AppInfo([
        'api_id' => <id>, // Remplacez par votre API ID
        'api_hash' => '<>' // Remplacez par votre API Hash
    ]),
    'logger' => new Logger([
        'logger_level' => 0 // Utilisation de 0 pour désactiver le journal
    ])
]);

$MadelineProto = new API('session.madeline', $settings);

$MadelineProto->start();

$groups = ['-00000000']; // Ajoutez ici les ID des groupes où vous souhaitez envoyer le message
$message = '
<>'; // Remplacez par votre message

// Boucle infinie pour envoyer le message toutes les 15 secondes
while (true) {
    foreach ($groups as $chatId) {
        try {
            $MadelineProto->messages->sendMessage(['peer' => $chatId, 'message' => $message]);
            echo "Message envoyé au groupe $chatId.<br>";
        } catch (Exception $e) {
            echo "Erreur lors de l'envoi au groupe $chatId : " . $e->getMessage() . "<br>";
        }
    }

    // Attendre 10 secondes avant de répéter l'envoi
    sleep(10);
}
?>
