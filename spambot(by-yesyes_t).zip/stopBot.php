<?php
$controlFile = 'stop_bot.txt';
file_put_contents($controlFile, 'stop');
echo "Le bot a été arrêté.";
?>
