<!DOCTYPE html>
<html>
<head>
    <title>Control Bot</title>
</head>
<body>
    <h1>Contrôler le Bot Telegram</h1>
    <form method="post" action="control.php">
        <button type="submit" name="action" value="start">Démarrer le Bot</button>
        <button type="submit" name="action" value="stop">Arrêter le Bot</button>
    </form>

    <?php
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $action = $_POST['action'];
        if ($action === 'start') {
            // Démarrer le bot en arrière-plan
            shell_exec('php startBot.php > /dev/null 2>&1 &');
            echo "Le bot a démarré.";
        } elseif ($action === 'stop') {
            // Arrêter le bot
            file_put_contents('stop_bot.txt', 'stop');
            echo "Le bot a été arrêté.";
        }
    }
    ?>
</body>
</html>
